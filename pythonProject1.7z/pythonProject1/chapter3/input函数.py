a = input("请输入一个数")
a = int(a)
b = input('请输入另一个数')
b = int(b)
print(a+b)

