print(1+1)
print(1-1)
print(2*6)
print(1/2)
print(19//3)
print(2**4)

# 一正一负整除
print(9//-4)  # 向下取整

# 赋值运算符
print('-------链式赋值-------')
a = b = c = 20  # 链式赋值
print(a, b, c)
print('-------参数赋值-------')
a = 20
print(a)
a += 30
print(a)
a -= 10
print(a)
a /= 10
print(a)
a *= 2
print(a)
print('-------解包赋值-------')
x, y, z = 10, 20, 30
print(x, y, z)
print('-------交换变量赋值-------')
m, n = 14, 15
m, n = n, m
print(m, n)

# 比较运算符
q, w = 1, 2
print(q < w)
print(q > w)
print(q <= w)
print(q >= w)
print(q == w)
print(q != w)
print('比较运算符输出的结果是bool类型')

# bool运算符

