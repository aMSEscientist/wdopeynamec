# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.


import numpy as np
import matplotlib.pyplot as plt
print(1+1)
x = np.linspace(-np.pi, np.pi, 50)
y = np.sin(x)
plt.plot(x, y)
plt.show()

fp = open("E:/text.txt", 'a+')
print('hello world', file=fp)
fp.close()


# See PyCharm help at https://www.jetbrains.com/help/pycharm/
