# 转义字符和原字符
print('hello\nworld')  # \n表示换行（newline）
print('hello\tworld')  # \t表示四个空格（tab）
print('hello\rworld')  # \r表示return（return）
print('hello\bworld')  # \b表示退格（backspace）
print('老师说：\'你们是啥子东西啊\'')

# 原字符，不希望转义字符起作用，就使用原字符，在字符串前面加上R 或者 r
print(r'我是危颖超\n哈哈哈哈哈')
