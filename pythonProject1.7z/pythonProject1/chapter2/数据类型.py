from decimal import Decimal
name = '危颖超'
print(name)
print('标识', id(name))
print('类型', type(name))
print('值', name)

# 整数数据类型 int
a = 12
b = -13
c = 0
print(a, b, c)
# 进制转换
print('十进制', 100)
print('二进制', 0b10001000)
print('八进制', 0o156)
print('十六进制', 0xAE11)

# 数据类型：浮点数
a1 = 1.1
a2 = 2.2
a3 = 2.1
print(a1+a2)
print(a1+a3)

# from decimal import Decimal
print(Decimal('1.1')+Decimal('2.2'))

# 数据类型：布尔类型
b1 = True
b2 = False
print(b1, type(b1))
print(b2, type(b2))
print(b1+1)
print(b2+1)

# 数据类型：字符串类型
str1 = '''人生苦短，
我用python'''
print(str1, type(str1))


s1 = '128'
f1 = 98.7
s2 = '76.77'
ff = True
s3 = 'hello'
print(type(s1), type(f1), type(s2), type(ff), type(s3))
print(int(s1), type(int(s1)))
# 将str转成int类型，字符串为 数字串
print(int(f1), type(int(f1)))
# f1oat转成int类型，截取整数部分，舍掉小数部分
# print (int (s2), type (int (s2)) ) 将str转成int类型，报错，因为字符串为小数串
print(int(ff), type(int(ff)))
# print (int (s3), type (int (s3),
# 将str转成int类型时，宇符串必须为数字串

'''sd
js
dj
'''















