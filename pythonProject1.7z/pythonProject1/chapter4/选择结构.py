print('---------分支结构---------')
money = 1000
s = int(input('请输入取款金额'))
if s <= money:
    money = money-s
    print('取款成功，余额为', money)
else:
    print('余额不足，请立即充值')


num = int(input('请输入一个数'))
if num % 2 == 0:
    print('num 是一个偶数')
else:
    print('num 是一个奇数')

score = int(input('请输入你的分数'))
if 100 >= score >= 90:
    print('A级')
elif 90 > score >= 80:
    print('B级')
elif 80 > score >= 70:
    print('C级')
elif 70 > score >= 60:
    print('D级')
elif 60 > score >= 0:
    print('E级')
else:
    print("请输入正确的分数")
